package jadx.core.dex.attributes;

public interface IAttribute {

	AType<?> getType();

}

#!/usr/bin/env sh
./gradlew build fatJar

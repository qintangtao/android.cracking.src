# Apktool Contributors
Copyright 2014 Ryszard Wiśniewski <brut.alll@gmail.com>

This product includes software developed by:

  * Ryszard Wiśniewski (brut.alll@gmail.com)
  * JesusFreke (https://github.com/JesusFreke/smali)
  * Dmitry Skiba (http://code.google.com/p/android4me/)
  * Tahseen Ur Rehman (http://code.google.com/p/radixtree/)
  * Connor Tumbleson (connor.tumbleson@gmail.com)
  * Android Open Source Project (http://source.android.com/)
  * The Apache Software Foundation (http://www.apache.org/)
